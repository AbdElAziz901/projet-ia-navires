# MODELE_KNN.PY
import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import classification_report, confusion_matrix
import joblib
import seaborn as sns
import matplotlib.pyplot as plt
from pathlib import Path
# 2. Chargement des fichiers d'entraînement et de test
DATA_DIR = Path(__file__).parent

X_train = pd.read_csv(DATA_DIR / "X_train.csv")
X_test  = pd.read_csv(DATA_DIR / "X_test.csv")
y_train = pd.read_csv(DATA_DIR / "y_train.csv")["VesselType"]
y_test  = pd.read_csv(DATA_DIR / "y_test.csv")["VesselType"]


# 2. Normalisation
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# 3. Modèle KNN
model = KNeighborsClassifier(n_neighbors=5)
model.fit(X_train_scaled, y_train)

# 4. Évaluation
y_pred = model.predict(X_test_scaled)
print("📊 Rapport de classification – KNN :")
print(classification_report(y_test, y_pred))

# 5. Matrice de confusion
cm = confusion_matrix(y_test, y_pred)
plt.figure(figsize=(10, 6))
sns.heatmap(cm, annot=True, fmt="d", cmap="Greens")
plt.title("Matrice de confusion – KNN")
plt.xlabel("Prédit")
plt.ylabel("Réel")
plt.savefig("matrice_confusion_knn.png")
plt.close()

# 6. Sauvegarde
joblib.dump(model, "model_knn.pkl")
joblib.dump(scaler, "scaler_knn.pkl")
