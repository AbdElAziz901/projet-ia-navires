import pandas as pd

# 1. Chargement des données
from pathlib import Path
csv_path = Path(__file__).parent / "export_IA.csv"
df = pd.read_csv(csv_path)


# 2. Encodage de TransceiverClass
df["TransceiverClass"] = df["TransceiverClass"].map({'A': 0, 'B': 1})

# 3. Liste des colonnes candidates (hors ID, noms, géo, dates)
colonnes_candidates = [
    'SOG', 'COG', 'Heading', 'Length', 'Width', 'Draft',
    'Cargo', 'Status', 'TransceiverClass', 'VesselType'
]

# 4. Suppression des lignes avec valeurs manquantes
df_filtered = df[colonnes_candidates].dropna()

# 5. Calcul de la matrice de corrélation
correlation_matrix = df_filtered.corr(numeric_only=True)
correlation_with_target = correlation_matrix["VesselType"].drop("VesselType").sort_values(ascending=False)

# 6. Affichage des corrélations
print("Corrélation avec VesselType :\n")
print(correlation_with_target)

# 7. Seuil de corrélation minimale à garder (modifiable)
SEUIL = 0.5

# 8. Sélection automatique des colonnes pertinentes
variables_pertinentes = correlation_with_target[correlation_with_target.abs() >= SEUIL].index.tolist()

# 9. Sauvegarde de la liste dans un fichier txt (ou utilisable par import dans d'autres scripts)
with open("variables_selectionnees.txt", "w") as f:
    for var in variables_pertinentes:
        f.write(var + "\n")

print("\n Variables retenues (corrélation >= ±" + str(SEUIL) + ") :")
print(variables_pertinentes)
print("\nListe enregistrée dans 'variables_selectionnees.txt'")





