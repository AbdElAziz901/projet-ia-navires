import joblib
import numpy as np

# Charger le modèle Dummy
model = joblib.load("model_dummy.pkl")
scaler = joblib.load("scaler_dummy.pkl")

# Saisie utilisateur
print("🔮 Prédiction avec Dummy Classifier")
print("Entrez les caractéristiques du navire :")
Cargo = int(input("Cargo : "))
Draft = float(input("Draft : "))
Width = float(input("Width : "))
Length = float(input("Length : "))


# Préparation
X_input = np.array([[Cargo, Draft, Width, Length]])
X_input_scaled = scaler.transform(X_input)

# Prédiction
prediction = model.predict(X_input_scaled)[0]
print(f"\n🛳️ (Dummy) Le navire est probablement de type : {prediction}")
