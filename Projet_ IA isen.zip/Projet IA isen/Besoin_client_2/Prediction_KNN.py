# PREDICTION_KNN.PY
import joblib
import numpy as np

# Chargement du modèle KNN et du scaler
model = joblib.load("model_knn.pkl")
scaler = joblib.load("scaler_knn.pkl")

# Saisie des caractéristiques du navire
print("Entrez les caractéristiques du navire :")
Cargo = int(input("Cargo : "))
Draft = float(input("Draft : "))
Width = float(input("Width : "))
Length = float(input("Length : "))


# Préparation des données
X_input = np.array([[Cargo, Draft, Width, Length]])
X_input_scaled = scaler.transform(X_input)

# Prédiction
prediction = model.predict(X_input_scaled)[0]

# Affichage
print(f"\n🛳️ Prédiction KNN : le navire est probablement de type : {prediction}")
