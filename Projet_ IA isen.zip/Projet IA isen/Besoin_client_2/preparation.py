# 1. Import des bibliothèques nécessaires
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

# 2. Chargement du fichier CSV
from pathlib import Path
csv_path = Path(__file__).parent / "export_IA.csv"
df = pd.read_csv(csv_path)

# 3. Lecture des variables pertinentes sélectionnées par corrélation
with open("variables_selectionnees.txt", "r") as f:
    features = [line.strip() for line in f.readlines()]

# 4. Encodage de TransceiverClass si utilisée
if 'TransceiverClass' in features:
    df['TransceiverClass'] = df['TransceiverClass'].map({'A': 0, 'B': 1})

# 5. Cible à prédire
target = 'VesselType'

# 6. Filtrage du DataFrame avec les colonnes pertinentes + cible
features_and_target = features + [target]
df = df[features_and_target].dropna()

# 7. Affichage pour vérification
print(" Variables sélectionnées :", features)
print("\nAperçu des données filtrées :")
print(df.head())

# 8. Distribution de la cible
print("\nDistribution de VesselType :")
print(df['VesselType'].value_counts())

# 9. Séparation X / y
X = df[features]
y = df[target]

# 10. Visualisation si 'Length' est présente
if 'Length' in features:
    plt.figure(figsize=(8, 6))
    sns.boxplot(x='VesselType', y='Length', data=df)
    plt.title('Longueur des navires par type')
    plt.xticks(rotation=45)
    plt.savefig('boxplot_length_vesseltype.png')
    plt.close()
    print(" Boxplot sauvegardé dans boxplot_length_vesseltype.png")

# 11. Sauvegarde des fichiers préparés
X.to_csv('X_prepared.csv', index=False)
y.to_csv('y_prepared.csv', index=False)
print("\n Données préparées sauvegardées dans X_prepared.csv et y_prepared.csv")

